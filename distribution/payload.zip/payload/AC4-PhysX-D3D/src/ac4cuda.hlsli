// ac4cuda.hlsli - common ABI for APEX CUDA kernels translated to D3D11 cs_5_0.
//
// ABI (the same one the future in-process nvcuda.dll will use):
//   b0 g_args : CUDA kernel parameters copied verbatim, one 32-bit word per PTX .param in declaration order
//               (u16 params are zero-extended to a word; struct params occupy ceil(size/4) words).
//               Words SYS_BASE.. hold values the CUDA driver would know: texref bindings and grid size.
//   u0 g_arena: the whole APEX device memory as one raw buffer. A 32-bit CUDA pointer is a byte offset.
//
// Exactness: PTX fma.rn.f32 / div.rn.f32 are IEEE correctly rounded. HLSL mad() may or may not fuse and
// float '/' is allowed 2.5 ulp, so with AC4_EXACT=1 they are emulated through doubles:
//   fma: a*b is exact in double (48 bits), the sum is done in double with round-to-odd (TwoSum error term),
//        then rounded once to float -> exactly fma.rn.f32.
//   div: double division is correctly rounded and 53 >= 2*24+2, so double->float rounding is innocuous.
// Plain float add/sub/mul are correctly rounded in D3D11; 'precise' stops the driver from contracting them.

#ifndef AC4_EXACT
#define AC4_EXACT 1
#endif

#define SYS_BASE   192          // word index; params use words 0..191
#define SYS_TEX    (SYS_BASE+32)// texref k (0..31): words SYS_TEX+4k.. = byte offset, element count, channels, bits of "1"
#define SYS_SCRATCH (SYS_BASE+15)// buffer byte offset of the per-group shared scratch (only for SHARED_BYTES > 32768)
#define SYS_NCTAID (SYS_BASE+16)// gridDim.x, gridDim.y, gridDim.z
#define SYS_ZERO   (SYS_BASE+19)// always 0 (the loader never writes it): a condition FXC cannot fold
#define SYS_CONST  (SYS_BASE+20)// arena offset of __constant__ symbol k (module constant memory lives in the arena)

cbuffer CudaArgs : register(b0) { uint4 g_args[128]; };   // 512 words: params 0..191, system 192..
RWByteAddressBuffer g_arena : register(u0);

// st.global.u8 / u16: SM5 has no sub-dword stores, and D3D11 refuses a second (typed R8/R16) UAV on the same
// buffer while the raw one is bound (stand 2026-10-17: the whole CSSetUnorderedAccessViews call is dropped).
// So: atomic clear + atomic set of the bits inside the dword (exact; neighbours own the other bytes).
void StoreU8(uint addr, uint v)
{
    uint sh = (addr & 3u) * 8u, w = addr & ~3u;
    g_arena.InterlockedAnd(w, ~(0xffu << sh));
    g_arena.InterlockedOr(w, (v & 0xffu) << sh);
}
void StoreU16(uint addr, uint v)
{
    uint sh = (addr & 2u) * 8u, w = addr & ~3u;
    g_arena.InterlockedAnd(w, ~(0xffffu << sh));
    g_arena.InterlockedOr(w, (v & 0xffffu) << sh);
}

uint  ArgU(uint i) { return g_args[i >> 2][i & 3]; }
uint  ConstU(uint k, uint off) { return g_arena.Load(g_args[(SYS_CONST + k) >> 2][(SYS_CONST + k) & 3] + off); }
int   ArgI(uint i) { return (int)ArgU(i); }
float ArgF(uint i) { return asfloat(ArgU(i)); }

// tex1Dfetch on linear memory, 1 x float32: (v,0,0,1); outside [0,count) returns 0 like the hardware.
float Tex1DFetchF(uint slot, int i)
{
    uint base = ArgU(SYS_TEX + 4 * slot);
    uint cnt  = ArgU(SYS_TEX + 4 * slot + 1);
    return ((uint)i < cnt) ? asfloat(g_arena.Load(base + (uint)i * 4u)) : 0.0f;
}
float4 Tex1DFetchF4(uint slot, int i)       // float4 texref: element = 16 bytes; count is in elements
{
    uint base = ArgU(SYS_TEX + 4 * slot);
    uint cnt  = ArgU(SYS_TEX + 4 * slot + 1);
    return ((uint)i < cnt) ? asfloat(g_arena.Load4(base + (uint)i * 16u)) : float4(0, 0, 0, 0);
}
uint Tex1DFetchU(uint slot, int i)
{
    uint base = ArgU(SYS_TEX + 4 * slot);
    uint cnt  = ArgU(SYS_TEX + 4 * slot + 1);
    return ((uint)i < cnt) ? g_arena.Load(base + (uint)i * 4u) : 0u;
}

// PTX semantics that HLSL does not guarantee (stand 2026-10-17: D3D11 min(NaN, c) returned NaN, PTX returns c):
//   min.f32 / max.f32: a NaN operand is ignored (both NaN -> NaN).
//   cvt.rzi.s32/u32.f32: NaN -> 0, saturate to the integer range.
float fmin_ptx(float a, float b) { return (a != a) ? b : ((b != b) ? a : min(a, b)); }
float fmax_ptx(float a, float b) { return (a != a) ? b : ((b != b) ? a : max(a, b)); }
int cvt_rzi_s32(float x)
{
    if (x != x) return 0;
    if (x >= 2147483648.0f) return 0x7fffffff;
    if (x <= -2147483648.0f) return (int)0x80000000;
    return (int)x;
}
uint cvt_rzi_u32(float x)
{
    if (!(x > 0.0f)) return 0u;                 // NaN, negative, zero
    if (x >= 4294967296.0f) return 0xffffffffu;
    return (uint)x;
}

// AC4_EXACT: 0 = plain HLSL (fast, not exact); 1 = through doubles (exact everywhere doubles exist, slow on
// consumer GPUs: FP64 is 1/64 rate); 2 = float only, exact when the driver compiles mad() to a fused FMA
// (checked at start-up by a probe shader; NVIDIA does).
float fma_rn(float a, float b, float c)
{
#if AC4_EXACT == 2
    return mad(a, b, c);
#elif AC4_EXACT == 1
    precise double p  = (double)a * (double)b;      // exact
    precise double dc = (double)c;
    precise double s  = p + dc;
    precise double bv = s - p;
    precise double e  = (p - (s - bv)) + (dc - bv); // exact error of s (TwoSum)
    if (e != 0.0)
    {
        uint lo, hi;
        asuint(s, lo, hi);
        if ((lo & 1u) == 0u)                         // round-to-odd: move s one ulp toward the exact sum
        {
            bool up = (e > 0.0) == (s > 0.0);         // exact value has larger magnitude than s
            if (up) lo += 1u;
            else { if (lo == 0u) hi -= 1u; lo -= 1u; }
            s = asdouble(lo, hi);
        }
    }
    return (float)s;
#else
    return mad(a, b, c);
#endif
}

// sqrt.rn.f32: hardware sqrt, then up to two one-ulp corrections. r = x - s*s is exact via fma (s within a few
// ulp). Midpoint test r > h*(2s+h) (h = half ulp, power of two): decided in float when r is clearly away from the
// rounded bound, otherwise exactly in double (x - s*s and h*(2s+h) fit in 53 bits). Ties are impossible for sqrt.
bool SqrtUp(float x, float s, float h, float r)
{
    float bf = mad(h, s + s, h * h);
    float tol = asfloat(asuint(bf) + 1u) - bf;
    if (abs(r - bf) > tol) return r > bf;
#if AC4_EXACT == 2
    // alpha 2, no doubles: bound = a + b with a = 2hs, b = h*h (both exact: h is a power of two); Fast2Sum gives the
    // exact error e of bf = fl(a + b) (|a| >= |b|); r - bf is exact (Sterbenz: r is within one ulp of bf here)
    precise float a = (s + s) * h, b = h * h, e = b - (bf - a);
    precise float d = r - bf;
    return d > e;
#else
    precise double ds = (double)s, dh = (double)h;
    return (double)x - ds * ds > dh * (ds + ds + dh);
#endif
}
bool SqrtDown(float x, float s, float h, float r)
{
    float bf = mad(h, s + s, -(h * h));
    float tol = asfloat(asuint(bf) + 1u) - bf;
    if (abs(-r - bf) > tol) return -r > bf;
#if AC4_EXACT == 2
    precise float a = (s + s) * h, b = -(h * h), e = b - (bf - a);   // bound = 2hs - h*h, same exact split
    precise float d = -r - bf;
    return d > e;
#else
    precise double ds = (double)s, dh = (double)h;
    return ds * ds - (double)x > dh * (ds + ds - dh);
#endif
}
float sqrt_rn(float x)
{
#if AC4_EXACT
    if (!(x > 0.0f) || x == asfloat(0x7f800000u)) return sqrt(x);    // 0, negative, nan, +inf
#ifdef SQRT_HW
    float s = sqrt(x);
#else
    // Start from rsqrt: plain sqrt() under IEEE strictness costs ~5x on the RTX 5090 (stand 2026-10-17); the
    // corrections below make the start value irrelevant as long as it is within one ulp after one Newton step.
    float y = rsqrt(x);
    float s = x * y;
    s = mad(mad(-s, s, x), 0.5f * y, s);
#endif
    [unroll] for (int k = 0; k < 2; k++)
    {
        float r = mad(-s, s, x);
        if (r > 0.0f)      { float s1 = asfloat(asuint(s) + 1u); if (SqrtUp(x, s, (s1 - s) * 0.5f, r)) s = s1; }
        else if (r < 0.0f) { float s0 = asfloat(asuint(s) - 1u); if (SqrtDown(x, s, (s - s0) * 0.5f, r)) s = s0; }
    }
    return s;
#else
    return sqrt(x);
#endif
}

float div_rn(float a, float b)
{
#if AC4_EXACT == 2
    // Specials (0, inf, nan) and huge/tiny exponents: hardware result (exact for specials).
    uint ea = (asuint(a) >> 23) & 255u, eb = (asuint(b) >> 23) & 255u;
    if (ea - 1u >= 253u || eb - 1u >= 253u || ea - eb + 120u > 240u) return a / b;
    float y = 1.0f / b;                 // approximate reciprocal
    float e = mad(-b, y, 1.0f);
    y = mad(e, y, y);                   // Newton step, ~0.5 ulp
    float q = a * y;
    float r = mad(-b, q, a);
    q = mad(r, y, q);                   // Markstein: nearly always correctly rounded
    // Final correction: fma gives the exact remainder, compare with the neighbour toward the true quotient.
    r = mad(-b, q, a);
    if (r != 0.0f)
    {
        bool up = (r > 0.0f) == (b > 0.0f);                  // true quotient > q
        int  step = (up == (q > 0.0f)) ? 1 : -1;             // in bit space, away from or toward zero
        float q1 = asfloat(asint(q) + step);
        float r1 = mad(-b, q1, a);
        if (abs(r1) < abs(r) || (abs(r1) == abs(r) && (asuint(q1) & 1u) == 0u)) q = q1;
    }
    return q;
#elif AC4_EXACT == 1
    precise double q = (double)a / (double)b;
    return (float)q;
#else
    return a / b;
#endif
}
